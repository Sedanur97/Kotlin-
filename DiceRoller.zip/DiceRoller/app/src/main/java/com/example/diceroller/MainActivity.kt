package com.example.diceroller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random as Random

class MainActivity : AppCompatActivity() {

    lateinit var diceImage : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val rollButton: Button = findViewById(R.id.roll_button)
        rollButton.text = "LETS ROLL"

        //created the rolldice function here
        rollButton.setOnClickListener {
            rollDice()
        }
        diceImage = findViewById(R.id.dice_image)

    }

/*
// func is here
// when you click the button after you will she the text and it wont dissapare
private fun rollDice() {
   val resultText : TextView = findViewById(R.id.result_text)
// gives radom numbers
   val randomInt = java.util.Random().nextInt(6) + 1
resultText.text = randomInt.toString()
     resultText.text = "Diced Rolled!"
}
}

 */
private fun rollDice() {
   val randomInt = java.util.Random().nextInt(6) + 1
   // val diceImage: ImageView = findViewById(R.id.dice_image)
    val drawableResources = when (randomInt) {
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        else -> R.drawable.dice_6
    }
   // val diceImage: ImageView = findViewById(R.id.dice_image)
    diceImage.setImageResource(drawableResources)
    // when we click; this button shows that a message for a second.
    Toast.makeText(this, "button clicked", Toast.LENGTH_SHORT).show()
    }
}