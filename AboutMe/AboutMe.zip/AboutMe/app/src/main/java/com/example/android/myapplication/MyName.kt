package com.example.android.myapplication

data class MyName (
    var name: String = "",
    var nickname: String = ""
        )



